import React, { useState, useEffect, useRef } from 'react'
import axios from 'axios'
import '../styles/Section.css'

const Section5 = () => {
    const [imageOrientation, setImageOrientation] = useState('')
    const [imageFrame, setImageFrame] = useState('')
    const [imageComponent1, setImageComponent1] = useState('')
    const [imageComponent2, setImageComponent2] = useState('')
    const [imageComponent3, setImageComponent3] = useState('')
    const [imageComponent4, setImageComponent4] = useState('')
    const [imageHeight, setImageHeight] = useState('')
    const [imageWidth, setImageWidth] = useState('')
    const [submitted, setSubmitted] = useState(false)

    const [imageFrameApi, setImageFrameApi] = useState(null)
    const [imageComponent1Api, setImageComponent1Api] = useState(null)
    const [imageComponent2Api, setImageComponent2Api] = useState(null)
    const [imageComponent3Api, setImageComponent3Api] = useState(null)
    const [imageComponent4Api, setImageComponent4Api] = useState(null)

    const [numberOfFrames, setNumberOfFrames] = useState(0);
    const [frames, setFrames] = useState([]);

    // We'll create refs to store references of generated canvases
    const canvasRefs = useRef([]);

    const handleGenerateFramesInputs = () => {
        const newFrames = Array.from({ length: numberOfFrames }, () => ({ height: '', width: '' }));
        setFrames(newFrames);
    };

    const handleFrameChange = (index, field, value) => {
        const updatedFrames = [...frames];
        updatedFrames[index][field] = value;
        setFrames(updatedFrames);
    };

    const formData = new FormData();

    const handleSubmit = async (e) => {
        e.preventDefault();
        formData.append("imageOrientation", imageOrientation);
        formData.append("imageFrame", imageFrameApi);
        formData.append("imageComponent1", imageComponent1Api);
        formData.append("imageComponent2", imageComponent2Api);
        formData.append("imageComponent3", imageComponent3Api);
        formData.append("imageComponent4", imageComponent4Api);
        formData.append("imageHeight", imageHeight);
        formData.append("imageWidth", imageWidth);
        setSubmitted(true);
    }

    const addFrame = async () => {
        const response = await axios.post('http://localhost:3000/add-data', formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            }
        })
        .then(res => console.log('res::', res))
        return response
    }

    function handleOnImageChange(event) {
        const file = event.currentTarget.files[0];
        const url = URL.createObjectURL(file);
        return { url, file }
    }

    const downloadImage = (idx) => {
        const canvas = canvasRefs.current[idx];
        if (!canvas) return;
        const link = document.createElement('a');
        link.download = `frame_${idx + 1}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
    }

    // useEffect to draw on canvas after submission
    useEffect(() => {
        if (!submitted || !imageFrame || frames.length === 0) return;

        // Preload all images
        const frameImg = new Image();
        const comp1Img = imageComponent1 ? new Image() : null;
        const comp2Img = imageComponent2 ? new Image() : null;
        const comp3Img = imageComponent3 ? new Image() : null;
        const comp4Img = imageComponent4 ? new Image() : null;

        const imagesToLoad = [frameImg];
        if (comp1Img) imagesToLoad.push(comp1Img);
        if (comp2Img) imagesToLoad.push(comp2Img);
        if (comp3Img) imagesToLoad.push(comp3Img);
        if (comp4Img) imagesToLoad.push(comp4Img);

        let loaded = 0;
        imagesToLoad.forEach(img => {
            img.onload = () => {
                loaded++;
                if (loaded === imagesToLoad.length) {
                    // All images loaded, draw on each canvas
                    frames.forEach((frame, idx) => {
                        const canvas = canvasRefs.current[idx];
                        if (!canvas) return;
                        const ctx = canvas.getContext('2d');
                        ctx.clearRect(0, 0, canvas.width, canvas.height);

                        // Draw the main frame:
                        ctx.drawImage(frameImg, 0, 0, frame.width, frame.height);

                        // Calculate innerDiv dimensions
                        // width and height reduced by frame.width/7 and frame.height/7 respectively
                        const innerDivWidth = frame.width - (frame.width / 7);
                        const innerDivHeight = frame.height - (frame.height / 7);

                        // innerDiv centered
                        const innerDivX = (frame.width - innerDivWidth) / 2;
                        const innerDivY = (frame.height - innerDivHeight) / 2;

                        // Draw inner div background (white) and border (red, 2px)
                        ctx.fillStyle = 'white';
                        ctx.fillRect(innerDivX, innerDivY, innerDivWidth, innerDivHeight);

                        ctx.lineWidth = 2;
                        ctx.strokeStyle = 'red';
                        ctx.strokeRect(innerDivX, innerDivY, innerDivWidth, innerDivHeight);

                        // Compute sizes for components:
                        const scaleFactor = (parseFloat(frame.width) + parseFloat(frame.height)) / 2;
                        const componentSizeSmall = scaleFactor * 0.15;
                        const componentSizeTie = scaleFactor * 0.15;
                        const componentSizeBox = scaleFactor * 0.15;

                        // Reproduce positions from your original code:

                        // specs (component1): top-left corner with translate(15%, 15%)
                        // Originally: top=0, left=0, then transform(15%,15%) means move by 0.15 * width and height
                        // For simplicity, since top=0 and left=0, we just offset by 15% of the component size:
                        if (comp1Img) {
                            const specsX = 0 + (0.15 * componentSizeSmall);
                            const specsY = 0 + (0.15 * componentSizeSmall);
                            ctx.drawImage(comp1Img, specsX, specsY);

                            // You could also add a border by drawing a rect if desired
                        }

                        // tie (component2): top-right with transform(25%,0%)
                        // top=0, right=0 means starting at frame.width - componentSizeTie at X
                        // translate(25%,0%) moves right by 0.25 * componentSizeTie
                        // So final X = frame.width - componentSizeTie + (0.25 * componentSizeTie) = frame.width - 0.75 * componentSizeTie
                        if (comp2Img) {
                            const tieX = frame.width - (0.75 * componentSizeTie);
                            const tieY = 0;
                            ctx.drawImage(comp2Img, tieX, tieY, componentSizeTie, componentSizeTie);
                        }

                        // sticker (component3): bottom-center with translate(-50%,0%)
                        // bottom=0 means y=frame.height - componentSizeSmall
                        // left=50% means x at frame.width/2
                        // translate(-50%,0%) means move x by -componentSizeSmall/2
                        if (comp3Img) {
                            const stickerX = (frame.width / 2) - (componentSizeSmall / 2);
                            const stickerY = frame.height - componentSizeSmall;
                            ctx.drawImage(comp3Img, stickerX, stickerY, componentSizeSmall, componentSizeSmall);
                        }

                        // box (component4): aligned left, top=frame.height *0.65, transform(-20%, -50%)
                        // top=frame.height*0.65 means y = frame.height*0.65
                        // translate(-20%, -50%) means move x by -0.2 * width, y by -0.5 * height
                        // Since left=0, X starts at 0 then move by -20% of componentSizeBox = -0.2*componentSizeBox
                        // This will place it slightly out of the frame if negative; adjust if needed. We'll follow original logic.
                        if (comp4Img) {
                            const boxX = (0 - 0.2 * componentSizeBox); 
                            const boxY = (frame.height * 0.65) - (0.5 * componentSizeBox);
                            ctx.drawImage(comp4Img, boxX, boxY, componentSizeBox, componentSizeBox);
                        }
                    });
                }
            }
        });

        frameImg.src = imageFrame;
        if (comp1Img) comp1Img.src = imageComponent1;
        if (comp2Img) comp2Img.src = imageComponent2;
        if (comp3Img) comp3Img.src = imageComponent3;
        if (comp4Img) comp4Img.src = imageComponent4;
    }, [submitted, frames, imageFrame, imageComponent1, imageComponent2, imageComponent3, imageComponent4]);


    return (
        <>
            <form className="max-w-md mx-auto bg-white p-6 rounded-md shadow-md space-y-6">
                {/* Image Orientation */}
                <div className="space-y-2">
                    <label
                        htmlFor="imageOrientation"
                        className="block font-semibold text-gray-700"
                    >
                        Image Type
                    </label>
                    <select
                        name="imageOrientation"
                        id="imageOrientation"
                        value={imageOrientation}
                        onChange={(e) => setImageOrientation(e.target.value)}
                        className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    >
                        <option value="">Select Image orientation</option>
                        <option value="landscape">Landscape</option>
                        <option value="portrait">Portrait</option>
                    </select>
                </div>

                {/* Upload Frame */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-frame"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Frame
                    </label>
                    {!imageFrame && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-frame"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageFrame(url);
                                    setImageFrameApi(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageFrame && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageFrame}
                                alt="Frame Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-image-frame"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageFrame('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Upload Component 1 */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-component1"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Component 1
                    </label>
                    {!imageComponent1 && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-component1"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageComponent1(url);
                                    setImageComponent1Api(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageComponent1 && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageComponent1}
                                alt="Component 1 Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-component-1"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageComponent1('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Upload Component 2 */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-component2"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Component 2
                    </label>
                    {!imageComponent2 && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-component2"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageComponent2(url);
                                    setImageComponent2Api(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageComponent2 && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageComponent2}
                                alt="Component 2 Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-component-2"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageComponent2('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Upload Component 3 */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-component3"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Component 3
                    </label>
                    {!imageComponent3 && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-component3"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageComponent3(url);
                                    setImageComponent3Api(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageComponent3 && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageComponent3}
                                alt="Component 3 Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-component-3"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageComponent3('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Upload Component 4 */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-component4"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Component 4
                    </label>
                    {!imageComponent4 && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-component4"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageComponent4(url);
                                    setImageComponent4Api(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageComponent4 && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageComponent4}
                                alt="Component 4 Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-component-4"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageComponent4('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Number of Frames Input */}
                <div className="space-y-2">
                    <label className="block font-semibold text-gray-700">
                        Enter Number of Frames You Want to Generate
                    </label>
                    <div className="flex items-center space-x-2">
                        <input
                            type="number"
                            value={numberOfFrames}
                            onChange={(e) => {
                                setSubmitted(false)
                                setNumberOfFrames(e.target.value)
                            }}
                            className="w-20 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                            placeholder="Count"
                        />
                        <button
                            type="button"
                            onClick={handleGenerateFramesInputs}
                            className="px-3 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 focus:outline-none"
                        >
                            Generate Inputs
                        </button>
                    </div>
                </div>

                {/* Dynamically Render Frame Dimension Inputs */}
                {frames.map((frame, index) => (
                    <div key={index} className="space-y-2">
                        <label className="block font-semibold text-gray-700">
                            Frame {index + 1} Dimensions (Height x Width)
                        </label>
                        <div className="flex items-center space-x-2">
                            <input
                                type="number"
                                value={frame.height}
                                onChange={(e) => handleFrameChange(index, 'height', e.target.value)}
                                className="w-20 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                                placeholder="Height"
                            />
                            <span className="text-gray-500 font-bold">X</span>
                            <input
                                type="number"
                                value={frame.width}
                                onChange={(e) => handleFrameChange(index, 'width', e.target.value)}
                                className="w-20 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                                placeholder="Width"
                            />
                        </div>
                    </div>
                ))}

                {/* Submit Button */}
                <div className="pt-4">
                    <button
                        onClick={(e) => handleSubmit(e)}
                        className="w-full py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    >
                        Generate Frame
                    </button>
                </div>
            </form>

            {/* Display Generated Canvases After Submission */}
            {submitted && imageFrame && frames.length > 0 && frames.map((frame, idx) => {
                return (
                    <div key={idx} style={{ margin: '20px', textAlign: 'center' }}>
                        {/* Create a canvas for each frame */}
                        <canvas
                            ref={el => canvasRefs.current[idx] = el}
                            width={frame.width}
                            height={frame.height}
                            style={{ border: '1px solid #000' }}
                        />
                        <div style={{ marginTop: '10px' }}>
                            <button
                                onClick={() => downloadImage(idx)}
                                className="px-4 py-2 bg-green-600 text-white rounded"
                            >
                                Download Image
                            </button>
                        </div>
                    </div>
                );
            })}
        </>
    )
}

export default Section5;
