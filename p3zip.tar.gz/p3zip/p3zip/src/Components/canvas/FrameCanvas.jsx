import React, { useRef, useEffect } from 'react';

export default function FrameCanvas({
  frame,
  imageFrame,
  imageComponent1,
  imageComponent2,
  imageComponent3,
  imageComponent4,
  onDownload
}) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!frame || !imageFrame) return;

    // Compute scale factor and component sizes
    const scaleFactor = (parseFloat(frame.width) + parseFloat(frame.height)) / 2;
    const componentSizeSmall = scaleFactor * 0.15;
    const componentSizeTie = scaleFactor * 0.15;
    const componentSizeBox = scaleFactor * 0.15;

    // Positions and transforms (converted from your CSS logic)
    const specsPos = {
      x: (frame.width * 0) + (0.15 * componentSizeSmall), 
      y: (frame.height * 0) + (0.15 * componentSizeSmall),
      w: componentSizeSmall,
      h: componentSizeSmall
    };

    const tiePos = {
      // top-right corner, translate(25%, 0%) approx means shift right by about 0.25 * size
      // If top-right corner is at (frame.width - componentSizeTie, 0)
      // After transform translate(25%, 0%), we move x by +0.25 * componentSizeTie to the right
      x: frame.width - componentSizeTie + (0.25 * componentSizeTie),
      y: 0,
      w: componentSizeTie,
      h: componentSizeTie
    };

    const stickerPos = {
      // bottom-center:
      // bottom:0 means y = frame.height - componentSizeSmall
      // translate(-50%, 0%) means shift x by half its width
      x: (frame.width / 2) - (componentSizeSmall / 2),
      y: frame.height - componentSizeSmall,
      w: componentSizeSmall,
      h: componentSizeSmall
    };

    const boxPos = {
      // left side at about 65% down
      // translate(-20%, -50%) means we shift left by 0.2 * width and up by 0.5 * height
      x: 0 - (0.2 * componentSizeBox),
      y: (frame.height * 0.65) - (0.5 * componentSizeBox),
      w: componentSizeBox,
      h: componentSizeBox
    };

    const innerDivPos = {
      // innerDiv is centered and scaled:
      width: frame.width - (frame.width / 7),
      height: frame.height - (frame.height / 7),
      x: (frame.width / 2) - (frame.width - frame.width / 7) / 2,
      y: (frame.height / 2) - (frame.height - frame.height / 7) / 2
    };

    const canvas = canvasRef.current;
    canvas.width = frame.width;
    canvas.height = frame.height;
    const ctx = canvas.getContext('2d');

    // Load all images before drawing:
    const loadImage = (src) => {
      return new Promise((resolve, reject) => {
        if (!src) return resolve(null);
        const img = new Image();
        img.crossOrigin = 'Anonymous'; // if needed for cross-domain images
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = src;
      });
    };

    Promise.all([
      loadImage(imageFrame),
      loadImage(imageComponent1),
      loadImage(imageComponent2),
      loadImage(imageComponent3),
      loadImage(imageComponent4)
    ]).then(([frameImg, c1, c2, c3, c4]) => {
      // Draw the frame image covering entire canvas
      ctx.drawImage(frameImg, 0, 0, frame.width, frame.height);

      // Draw innerDiv (white background and red border)
      ctx.fillStyle = 'white';
      ctx.fillRect(innerDivPos.x, innerDivPos.y, innerDivPos.width, innerDivPos.height);
      ctx.lineWidth = 2;
      ctx.strokeStyle = 'red';
      ctx.strokeRect(innerDivPos.x, innerDivPos.y, innerDivPos.width, innerDivPos.height);

      // Draw components if available
      if (c1) {
        ctx.drawImage(c1, specsPos.x, specsPos.y, specsPos.w, specsPos.h);
      }

      if (c2) {
        ctx.drawImage(c2, tiePos.x, tiePos.y, tiePos.w, tiePos.h);
      }

      if (c3) {
        ctx.drawImage(c3, stickerPos.x, stickerPos.y, stickerPos.w, stickerPos.h);
      }

      if (c4) {
        ctx.drawImage(c4, boxPos.x, boxPos.y, boxPos.w, boxPos.h);
      }

      // Once done, we can call onDownload to update parent about image ready
      if (onDownload) {
        onDownload(canvas);
      }
    }).catch(err => {
      console.error('Error loading images', err);
    });

  }, [frame, imageFrame, imageComponent1, imageComponent2, imageComponent3, imageComponent4, onDownload]);

  return (
    <div>
      <canvas ref={canvasRef} style={{ border: '1px solid #000' }} />
    </div>
  );
}
