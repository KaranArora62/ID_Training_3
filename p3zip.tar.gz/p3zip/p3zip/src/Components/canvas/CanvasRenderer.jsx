
import React, { useRef, useEffect } from 'react';

const CanvasRenderer = ({ submitted, imageFrame, frames, imageComponents }) => {
  const canvasRef = useRef(null);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    const link = document.createElement('a');
    link.download = 'styled-image.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const drawCanvas = () => {
    if (!submitted || !imageFrame || frames.length === 0) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    frames.forEach((frame, idx) => {
      console.log(`Index ${idx}: Frame Height:${frame.height} , Frame Width:${frame.width}`);

      const scaleFactor = (parseFloat(frame.width) + parseFloat(frame.height)) / 2;
      const componentSizeSmall = scaleFactor * 0.15;
      const componentSizeTie = scaleFactor * 0.15;
      const componentSizeBox = scaleFactor * 0.15;

      // Set canvas size
      canvas.width = frame.width;
      canvas.height = frame.height;

      // Draw frame image
      const frameImage = new Image();
      frameImage.src = imageFrame;
      frameImage.onload = () => {
        ctx.drawImage(frameImage, 0, 0, frame.width, frame.height);

        // Draw inner rectangle (innerDiv)
        const innerDivWidth = frame.width * (6 / 7); // 100% - 1/7
        const innerDivHeight = frame.height * (6 / 7);
        const innerDivX = (frame.width - innerDivWidth) / 2;
        const innerDivY = (frame.height - innerDivHeight) / 2;

        ctx.fillStyle = 'white';
        ctx.fillRect(innerDivX, innerDivY, innerDivWidth, innerDivHeight);

        // Draw components
        const components = [
          {
            image: imageComponents[0],
            x: frame.width * 0.0 + componentSizeSmall * 0.15,
            y: frame.height * 0.0 + componentSizeSmall * 0.15,
            size: componentSizeSmall,
          },
          {
            image: imageComponents[1],
            x: frame.width - componentSizeTie * 1.25,
            y: frame.height * 0.0 + componentSizeTie * 0.15,
            size: componentSizeTie,
          },
          {
            image: imageComponents[2],
            x: frame.width / 2 - componentSizeSmall / 2,
            y: frame.height - componentSizeSmall,
            size: componentSizeSmall,
          },
          {
            image: imageComponents[3],
            x: componentSizeBox * -0.2,
            y: frame.height * 0.65 - componentSizeBox / 2,
            size: componentSizeBox,
          },
        ];

        components.forEach(({ image, x, y, size }, i) => {
          if (image) {
            const compImage = new Image();
            compImage.src = image;
            compImage.onload = () => {
              ctx.drawImage(compImage, x, y, size, size);
            };
          }
        });
      };
    });
  };

  useEffect(() => {
    drawCanvas();
  }, [submitted, imageFrame, frames, imageComponents]);

  return (
    <div>
      <canvas ref={canvasRef} style={{ border: '1px solid #000' }}></canvas>
      <button onClick={handleDownload}>Download Styled Image</button>
    </div>
  );
};

export default CanvasRenderer;
