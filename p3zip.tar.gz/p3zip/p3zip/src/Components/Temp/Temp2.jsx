import React, { useState } from 'react';
import bgFrame from '../../images/bg-frame.png';
import specs from '../../images/cloud_icon03.svg';
import tie from '../../images/cloud_icon01.svg';
import sticker from '../../images/fathersday.svg';
import box from '../../images/cloud_icon02.svg';

const Temp2 = () => {
    const [height, setHeight] = useState(500);
    const [width, setWidth] = useState(1000);

    const scaleFactor = (width + height) / 2;
    
    const containerStyle = {
        position: 'relative',
        margin: '50px auto',
        width: `${width}px`,
        height: `${height}px`,
        border: '1px solid #000000',
        overflow: 'hidden',
    };

    // Inner div scales proportionally
    const innerDiv = {
        zIndex: 1,
        position: 'absolute',
        // width: `${width * 0.83}px`,
        // height: `${height * 0.83}px`,
        // width: "calc(100% - 100px)",
        width:`calc(100% -  ${width/7}px)`,
        height:`calc(100% -  ${height/7}px)`,
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        backgroundColor: 'white',
        // border: '2px solid red',
    };

    const componentSizeSmall = scaleFactor * 0.15;
    const componentSizeTie = scaleFactor * 0.15;
    const componentSizeBox = scaleFactor * 0.15;

    // specs top-left
    const specsStyle = {
        zIndex: 2,
        position: 'absolute',
        width: `${componentSizeSmall}px`,
        height: `${componentSizeSmall}px`,
        top: `${height * 0}px`,
        left: `${width * 0}px`,
        transform: 'translate(15%, 15%)',
        border: '1px solid #000000',
    };

    // tie top-right
    const tieStyle = {
        zIndex: 2,
        position: 'absolute',
        width: `${componentSizeTie}px`,
        height: `${componentSizeTie}px`,
        top: `${height * 0.0}px`,
        right: `${width * 0.0}px`,
        transform: 'translate(25%, 0%)',
        border: '1px solid #000000',
    };

    // sticker bottom-center
    const stickerStyle = {
        zIndex: 2,
        position: 'absolute',
        width: `${componentSizeSmall}px`,
        height: `${componentSizeSmall}px`,
        bottom: `0%`,
        left: '50%',
        transform: 'translate(-50%, 0%)',
        border: '1px solid #000000',
    };

    // box aligned left
    // Use a smaller percentage for left or even a fixed pixel offset to keep it close.
    const boxStyle = {
        zIndex: 2,
        position: 'absolute',
        width: `${componentSizeBox}px`,
        height: `${componentSizeBox}px`,
        top: `${height * 0.65}px`,
        left: `${width * 0.00}px`,    // smaller than 0.1 to keep it closer to the edge as we scale
        border: '1px solid #000000',
        transform: 'translate(-20%, -50%)',
        // objectFit: 'cover',
    };

    return (
        <div style={containerStyle}>
            <img
                style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    objectFit: 'cover',
                }}
                src={bgFrame}
                alt="frame"
            />
            <div style={innerDiv}></div>
            <img src={specs} alt="specs" style={specsStyle} />
            <img src={tie} alt="tie" style={tieStyle} />
            <img src={sticker} alt="sticker" style={stickerStyle} />
            <img src={box} alt="box" style={boxStyle} />
        </div>
    );
}

export default Temp2;
