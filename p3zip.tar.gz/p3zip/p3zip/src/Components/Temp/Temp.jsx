import React, { useState } from 'react'
import bgFrame from '../../images/bg-frame.png'
import specs from '../../images/cloud_icon03.svg'
import tie from '../../images/cloud_icon01.svg'
import sticker from '../../images/fathersday.svg'
import box from '../../images/cloud_icon02.svg'


const Temp = () => {

    const [height, setHeight] = useState(1000); // Numeric values
    const [width, setWidth] = useState(1000);

    const containerStyle = {
        position: 'relative',
        margin: '50px auto',
        width: `${width}px`,
        height: `${height}px`,
    };

    const frameStyle = {
        width: '100%',
        height: '100%',
        position: 'relative',
        top: 0,
        left: 0,
        border: '1px solid #000000',
        objectFit: 'cover',
    };

    const innerDiv = {
        zIndex: 1,
        backgroundColor: 'white',
        width: '80%',
        height: '80%',
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        border: '2px solid red',
    };

    // Dynamic styles for specs, tie, sticker, and box
    const specsStyle = {
        zIndex: 2,
        height: `${height * 0.15}px`,
        width: `${width * 0.15}px`,
        position: 'absolute',
        top: `${height * 0.05}px`, // Position relative to height
        left: `${width * 0.05}px`, // Position relative to width
        transform: 'translate(0, 0)', // No centralizing shift needed
        border: '1px solid #000000',
    };

    const tieStyle = {
        zIndex: 2,
        height: `${height * 0.15}px`,
        width: `${width * 0.15}px`,
        position: 'absolute',
        top: `${height * 0.1}px`,
        right: `${width * 0.1}px`,
        transform: 'translate(0, 0)',
        border: '1px solid #000000',
    };

    const stickerStyle = {
        zIndex: 2,
        height: `${height * 0.15}px`,
        width: `${width * 0.15}px`,
        position: 'absolute',
        bottom: `${height * 0.1}px`,
        left: '50%',
        transform: 'translate(-50%, 0)',
        border: '1px solid #000000',
    };

    const boxStyle = {
        zIndex: 2,
        height: `${height * 0.2}px`, // Scaled size
        width: `${width * 0.2}px`, // Scaled size
        position: 'absolute',
        top: `${height * 0.75}px`, // Positioned at 75% of the container's height
        left: `${width * 0.1}px`, // Slightly inset from the left edge
        transform: 'translate(0, -50%)', // Adjust vertical alignment
        border: '1px solid #000000',

    };


    return (
        <div style={containerStyle}>
            <img style={frameStyle} src={bgFrame} alt="i1" />
            <div style={innerDiv}></div>
            <img src={specs} alt="c1" name="comp1" style={specsStyle} />
            <img src={tie} alt="c2" name="comp2" style={tieStyle} />
            <img src={sticker} alt="c3" name="comp3" style={stickerStyle} />
            <img src={box} alt="c4" name="comp4" style={boxStyle} />
        </div>
    );

}
export default Temp