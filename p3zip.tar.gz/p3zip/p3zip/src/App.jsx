import './App.css'
import Navbar from './Components/Navbar'
import Section from './Components/Section'
import Section2 from './Components/Section2'
import Section3 from './Components/Section3'
import Section4 from './Components/Section4'
import Section5 from './Components/Section5'
import Temp from './Components/Temp/Temp'
import Temp2 from './Components/Temp/Temp2'

function App() {
  
  return (
    <>
      <Navbar />
      <Section2 />
      {/* <Temp2 /> */}
    </>
  )
}

export default App
