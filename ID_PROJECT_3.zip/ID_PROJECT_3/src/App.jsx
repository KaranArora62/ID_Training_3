import './App.css'
import Navbar from './Components/Navbar'
import Section from './Components/Section'
import Section2 from './Components/Section2'
import Section3 from './Components/Section3'
import Section4 from './Components/Section4'
import Temp from './Components/Temp/Temp'

function App() {
  
  return (
    <>
      <Navbar />
      {/* <Section3 /> */}
      <Temp />
    </>
  )
}

export default App
