import React, { useState } from 'react'
import axios from 'axios'
import '../styles/Section.css'

// import { addFrame } from '../api/frames'

const Section = () => {

    const [imageOrientation, setImageOrientation] = useState('')
    const [imageFrame, setImageFrame] = useState('')
    const [imageComponent1, setImageComponent1] = useState('')
    const [imageComponent2, setImageComponent2] = useState('')
    const [imageComponent3, setImageComponent3] = useState('')
    const [imageComponent4, setImageComponent4] = useState('')
    const [imageHeight, setImageHeight] = useState('')
    const [imageWidth, setImageWidth] = useState('')

    const [submitted, setSubmitted] = useState(false);

    // states for API
    // const [imageOrientationApi, setImageOrientationApi] = useState('')
    const [imageFrameApi, setImageFrameApi] = useState(null)
    const [imageComponent1Api, setImageComponent1Api] = useState(null)
    const [imageComponent2Api, setImageComponent2Api] = useState(null)
    const [imageComponent3Api, setImageComponent3Api] = useState(null)
    const [imageComponent4Api, setImageComponent4Api] = useState(null)
    // const [imageHeightApi, setImageHeightApi] = useState('')
    // const [imageWidthApi, setImageWidthApi] = useState('')
    const formData = new FormData();


    const handleSubmit = async (e) => {
        e.preventDefault();

        formData.append("imageOrientation", imageOrientation);
        formData.append("imageFrame", imageFrameApi);
        formData.append("imageComponent1", imageComponent1Api);
        formData.append("imageComponent2", imageComponent2Api);
        formData.append("imageComponent3", imageComponent3Api);
        formData.append("imageComponent4", imageComponent4Api);
        formData.append("imageHeight", imageHeight);
        formData.append("imageWidth", imageWidth);


        const formValues = {
            imageOrientation: imageOrientation,
            imageFrame: imageFrame,
            imageComponent1: imageComponent1,
            imageComponent2: imageComponent2,
            imageComponent3: imageComponent3,
            imageComponent4: imageComponent4,
            imageHeight: imageHeight,
            imageWidth: imageWidth
        }

        setSubmitted(true)
    }
    const addFrame = async () => {
        console.log('data In API ::', formData);

        const response = await axios.post('http://localhost:3000/add-data', formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            }
        })
            .then(res => console.log('res::', res))
        return response
    }

    function handleOnImageChange(event) {
        const file = event.currentTarget.files[0];
        console.log("file::", file)
        const url = URL.createObjectURL(file);
        return { url, file }
    }


    const containerStyle = {
        position: 'relative',
        margin: '50px auto',
        width: `${imageWidth ? imageWidth : '200'}px`,
        height: `${imageHeight ? imageHeight : '200'}px`,
    }

    const frameStyle = {
        width: `${imageWidth ? imageWidth : '200'}px`,
        height: `${imageHeight ? imageHeight : '200'}px`,
        position: 'relative',
        top: 0,
        left: 0,
        border: '1px solid #000000',
        objectFit: 'cover',
    };

    const component1Style = {
        height: '50px',
        width: '50px',
        position: 'absolute',
        top: '100%',
        left: '50%',
        transform: "translate(-50%,-50%)",
        border: '1px solid #000000'
    }
    const component2Style = {
        height: '50px',
        width: '50px',
        position: 'absolute',
        top: '0',
        left: '100%',
        transform: "translate(-50%,-50%)",
        border: '1px solid #000000'
    }
    const component3Style = {
        height: '50px',
        width: '50px',
        position: 'absolute',
        bottom: '0',
        left: '0',
        transform: "translate(-50%,-100%)",
        border: '1px solid #000000'
    }

    const component4Style = {
        height: '50px',
        width: '50px',
        position: 'absolute',
        top: '0',
        right: '100%',
        transform: "translate(50%,-50%)",
        border: '1px solid #000000'
    }

    return (
        <>
            <form>

                <label htmlFor="imageOrientation">Image Type</label>
                <select name="imageOrientation" id="imageOrientation" onChange={(e) => setImageOrientation(e.target.value)} value={imageOrientation}>
                    <option value="">Select Image orientation</option>
                    <option value="landscape">Landscape</option>
                    <option value="portrait">Portrait</option>
                </select>

                <Form.Select aria-label="Default select example">
                    <option>Open this select menu</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                    <option value="3">Three</option>
                </Form.Select>
                <br /><br />
                <label htmlFor="upload-frame">Upload Frame</label>
                {!imageFrame && <input type="file" name='upload-frame' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageFrame(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageFrameApi(file);
                }} />}

                {imageFrame && <><img src={imageFrame} height='100' width='100' />
                    <button name='button-image-frame' onClick={(e) => setImageFrame('')}>Remove</button></>}
                <br /><br />
                <label htmlFor="upload-component1">Upload Component 1</label>
                {!imageComponent1 && <input type="file" name='upload-component1' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageComponent1(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageComponent1Api(file);
                }} />}
                {imageComponent1 && <><img src={imageComponent1} height='100' width='100' />
                    <button name='button-component-1' onClick={(e) => setImageComponent1('')}>Remove</button></>}
                <br /><br />

                <label htmlFor="upload-component2">Upload Component 2</label>
                {!imageComponent2 && <input type="file" name='upload-component2' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageComponent2(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageComponent2Api(file);
                }} />}

                {imageComponent2 && <><img src={imageComponent2} height='100' width='100' />
                    <button name='button-component-2' onClick={(e) => setImageComponent2('')}>Remove</button></>}

                <br /><br />

                <label htmlFor="upload-component3">Upload Component 3</label>

                {!imageComponent3 && <input type="file" name='upload-component3' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageComponent3(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageComponent3Api(file);
                }} />}

                {imageComponent3 && <><img src={imageComponent3} height='100' width='100' />
                    <button name='button-component-3' onClick={(e) => setImageComponent3('')}>Remove</button></>}
                <br /><br />

                <label htmlFor="upload-component4">Upload Component 4</label>
                {!imageComponent4 && <input type="file" name='upload-component4' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageComponent4(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageComponent4Api(file);
                }} />}
                {imageComponent4 && <><img src={imageComponent4} height='100' width='100' />
                    <button name='button-component-4' onClick={(e) => setImageComponent4('')}>Remove</button></>}

                <br /><br />

                <label htmlFor="imageSizes">Image Height and Width : </label>
                <input type="number" name='imageLength' style={{ width: '60px', height: '40px' }} onChange={(e) => setImageHeight(e.target.value)} value={imageHeight} />
                <span> X </span>
                <input type="number" name='imageWidth' style={{ width: '60px', height: '40px' }} onChange={(e) => setImageWidth(e.target.value)} value={imageWidth} />
                <br /><br />

                <button onClick={(e) => handleSubmit(e)}>Generate Frame</button>
            </form>
            {
                submitted && imageFrame
                    ? <div style={containerStyle} >
                        <img style={frameStyle} src={imageFrame} alt='i1' />
                        {imageComponent1 && <img src={imageComponent1} alt="c1" name='comp1' style={component1Style} />}
                        {imageComponent2 && <img src={imageComponent2} alt="c2" name='comp2' style={component2Style} />}
                        {imageComponent3 && <img src={imageComponent3} alt="c3" name='comp3' style={component3Style} />}
                        {imageComponent4 && <img src={imageComponent4} alt="c4" name='comp4' style={component4Style} />}
                    </div>
                    :
                    null
            }
        </>
    )
}

export default Section