import React, { useState } from 'react'
import '../styles/Section.css'
import frameImage from '../images/bg-frame.png'
import fathersdayImage from '../images/fathersday.svg'
const Section2 = () => {
    const [stateValues, setStateValues] = useState([]);


    const [imageOrientation, setImageOrientation] = useState('')
    const [imageComponent1, setImageComponent1] = useState(false)
    const [imageComponent2, setImageComponent2] = useState(false)
    const [imageComponent3, setImageComponent3] = useState(false)
    const [imageComponent4, setImageComponent4] = useState(false)
    const [imageLength, setImageLength] = useState('')
    const [imageWidth, setImageWidth] = useState('')


    const handleSubmit = (e) => {
        e.preventDefault();
        // console.log('image orientation',imageOrientation);
        // console.log('image c1',imageComponent1);
        // console.log('image c2',imageComponent2);
        // console.log('image c3',imageComponent3);
        // console.log('image c4',imageComponent4);
        // console.log('image length',imageLength);
        // console.log('image width',imageWidth);

        const imageConfig = {
            imageOrientation: imageOrientation,
            imageComponent1: imageComponent1,
            imageComponent2: imageComponent2,
            imageComponent3: imageComponent3,
            imageComponent4: imageComponent4,
            imageLength: imageLength,
            imageWidth: imageWidth
        }
        console.log(imageConfig);

    }
    return (
        <>
            <form>

                <label htmlFor="imageOrientation">Image Type</label>
                <select name="imageOrientation" id="imageOrientation" onChange={(e) => setImageOrientation(e.target.value)} value={imageOrientation}>
                    <option value="">Select Image orientation</option>
                    <option value="landscape">Landscape</option>
                    <option value="portrait">Portrait</option>
                </select>
                <br /><br />

                <label htmlFor="select-components">Select Components</label>
                <label className="container">One
                    <input type="checkbox" onChange={(e) => setImageComponent1(e.target.checked)} checked={imageComponent1} />
                    <span className="checkmark"></span>
                </label>
                <label className="container">Two
                    <input type="checkbox" onChange={(e) => setImageComponent2(e.target.checked)} checked={imageComponent2} />
                    <span className="checkmark"></span>
                </label>
                <label className="container">Three
                    <input type="checkbox" onChange={(e) => setImageComponent3(e.target.checked)} checked={imageComponent3} />
                    <span className="checkmark"></span>
                </label>
                <label className="container">Four
                    <input type="checkbox" onChange={(e) => setImageComponent4(e.target.checked)} checked={imageComponent4} />
                    <span className="checkmark"></span>
                </label>
                <br /><br />


                <label htmlFor="imageSizes">Image Length and Width</label>
                <input type="number" name='imageLength' style={{ width: '40px', height: '40px' }} onChange={(e) => setImageLength(e.target.value)} value={imageLength} />
                <span>*</span>
                <input type="number" name='imageWidth' style={{ width: '40px', height: '40px' }} onChange={(e) => setImageWidth(e.target.value)} value={imageWidth} />
                <br /><br />
                <button onClick={(e) => handleSubmit(e)}>Generate Frame</button>
            </form>




            {/* <div className='image-container'>
                <div className="image-frame">
                    <img className='left' src={frameImage} alt="frame image" />
                    <div class="sticker">
                        <img src={fathersdayImage} alt="Sticker" />
                    </div>
                </div>
            </div> */}
        </>
    )
}

export default Section2