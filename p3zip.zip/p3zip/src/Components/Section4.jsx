import React, { useState } from 'react'
import '../styles/Section.css'
const Section4 = () => {
    // const [stateValues, setStateValues] = useState([]);


    const [imageOrientation, setImageOrientation] = useState('')
    const [imageFrame, setImageFrame] = useState('')
    const [imageComponent1, setImageComponent1] = useState('')
    const [imageComponent2, setImageComponent2] = useState('')
    const [imageComponent3, setImageComponent3] = useState('')
    const [imageComponent4, setImageComponent4] = useState('')
    const [imageHeight, setImageHeight] = useState('')
    const [imageWidth, setImageWidth] = useState('')

    const [submitted, setSubmitted] = useState(false);


    const handleSubmit = (e) => {
        e.preventDefault();
        // console.log('image orientation',imageOrientation);
        // console.log('image c1',imageComponent1);
        // console.log('image c2',imageComponent2);
        // console.log('image c3',imageComponent3);
        // console.log('image c4',imageComponent4);
        // console.log('image length',imageLength);
        // console.log('image width',imageWidth); 

        const formValues = {
            imageOrientation: imageOrientation,
            imageFrame: imageFrame,
            imageComponent1: imageComponent1,
            imageComponent2: imageComponent2,
            imageComponent3: imageComponent3,
            imageComponent4: imageComponent4,
            imageHeight: imageHeight,
            imageWidth: imageWidth
        }
        console.log(formValues);
        setSubmitted(true)
    }

    function handleOnImageChange(event) {
        const file = event.currentTarget.files[0];
        console.log("file::", file)
        const url = URL.createObjectURL(file);
        return url
    }


    const containerStyle = {
        position: 'relative',
        margin:'0 auto',
        width: `${imageWidth ? imageWidth : '200'}px`,
        height: `${imageHeight ? imageHeight : '200'}px`,
    }

    const frameStyle = {
        width: `${imageWidth ? imageWidth : '200'}px`,
        height: `${imageHeight ? imageHeight : '200'}px`,
        position: 'relative',
        top: 0,
        left: 0,
        border: '1px solid #000000',
        objectFit: 'cover',
        // overflow:'hidden'
    };

    const component1Style = {
        height:'50px',
        width:'50px',
        position: 'absolute',
        top: '100%',
        left: '50%',
        transform:"translate(-50%,-50%)",
        border: '1px solid #000000'
    }
    const component2Style = {
        height:'50px',
        width:'50px',
        position: 'absolute',
        top: '0',
        left: '100%',
        transform:"translate(-50%,-50%)",
        border: '1px solid #000000'
    }
    const component3Style = {
        height:'50px',
        width:'50px',
        position: 'absolute',
        bottom: '0',
        left: '0',
        transform:"translate(-50%,-100%)",
        border: '1px solid #000000'
    }
    
    const component4Style = {
        height:'50px',
        width:'50px',
        position: 'absolute',
        top: '0',
        right: '100%',
        transform:"translate(50%,-50%)",
        border: '1px solid #000000'
    }

    return (
        <>
            <form>

                <label htmlFor="imageOrientation">Image Type</label>
                <select name="imageOrientation" id="imageOrientation" onChange={(e) => setImageOrientation(e.target.value)} value={imageOrientation}>
                    <option value="">Select Image orientation</option>
                    <option value="landscape">Landscape</option>
                    <option value="portrait">Portrait</option>
                </select>
                <br /><br />
                <label htmlFor="upload-frame">Upload Frame</label>
                {!imageFrame && <input type="file" name='upload-frame' onChange={(e) => {
                    const val = handleOnImageChange(e);
                    console.log(`${e.target.name} val::`, val);
                    setImageFrame(val);
                }} />}

                {imageFrame && <><img src={imageFrame} height='100' width='100' />
                    <button name='button-image-frame' onClick={(e) => setImageFrame('')}>Remove</button></>}
                <br /><br />
                <label htmlFor="upload-component1">Upload Component 1</label>
                {!imageComponent1 && <input type="file" name='upload-component1' onChange={(e) => {
                    const val = handleOnImageChange(e);
                    console.log(`${e.target.name} val::`, val);
                    setImageComponent1(val);
                }} />}
                {imageComponent1 && <><img src={imageComponent1} height='100' width='100' />
                    <button name='button-component-1' onClick={(e) => setImageComponent1('')}>Remove</button></>}
                <br /><br />

                <label htmlFor="upload-component2">Upload Component 2</label>
                {!imageComponent2 && <input type="file" name='upload-component2' onChange={(e) => {
                    const val = handleOnImageChange(e);
                    console.log(`${e.target.name} val::`, val);
                    setImageComponent2(val);
                }} />}

                {imageComponent2 && <><img src={imageComponent2} height='100' width='100' />
                    <button name='button-component-2' onClick={(e) => setImageComponent2('')}>Remove</button></>}

                <br /><br />

                <label htmlFor="upload-component3">Upload Component 3</label>

                {!imageComponent3 && <input type="file" name='upload-component3' onChange={(e) => {
                    const val = handleOnImageChange(e);
                    console.log(`${e.target.name} val::`, val);
                    setImageComponent3(val);
                }} />}

                {imageComponent3 && <><img src={imageComponent3} height='100' width='100' />
                    <button name='button-component-3' onClick={(e) => setImageComponent3('')}>Remove</button></>}
                <br /><br />

                <label htmlFor="upload-component4">Upload Component 4</label>
                {!imageComponent4 && <input type="file" name='upload-component4' onChange={(e) => {
                    const val = handleOnImageChange(e);
                    console.log(`${e.target.name} val::`, val);
                    setImageComponent4(val);
                }} />}
                {imageComponent4 && <><img src={imageComponent4} height='100' width='100' />
                    <button name='button-component-4' onClick={(e) => setImageComponent4('')}>Remove</button></>}

                <br /><br />


                <label htmlFor="imageSizes">Image Height and Width</label>
                <input type="number" name='imageLength' style={{ width: '40px', height: '40px' }} onChange={(e) => setImageHeight(e.target.value)} value={imageHeight} />
                <span>*</span>
                <input type="number" name='imageWidth' style={{ width: '40px', height: '40px' }} onChange={(e) => setImageWidth(e.target.value)} value={imageWidth} />
                <br /><br />

                <button onClick={(e) => handleSubmit(e)}>Generate Frame</button>
            </form>
            {
                submitted && imageFrame
                    ? <div style={containerStyle} >
                        <img style={frameStyle} src={imageFrame} alt='i1' />
                        {imageComponent1 && <img src={imageComponent1} alt="c1" name='comp1' style={component1Style} />}
                        {imageComponent2 && <img src={imageComponent2} alt="c2" name='comp2' style={component2Style} />}
                        {imageComponent3 && <img src={imageComponent3} alt="c3" name='comp3' style={component3Style} />}
                        {imageComponent4 && <img src={imageComponent4} alt="c4" name='comp4' style={component4Style}/>}
                    </div>
                    :
                    null
            }
        </>
    )
}

export default Section4