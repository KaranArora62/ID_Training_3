import React, { useState, useRef } from 'react'
import axios from 'axios'
import '../styles/Section.css'
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// import { addFrame } from '../api/frames'

const Section5 = () => {

    const [imageOrientation, setImageOrientation] = useState('')
    const [imageFrame, setImageFrame] = useState('')
    const [imageComponent1, setImageComponent1] = useState('')
    const [imageComponent2, setImageComponent2] = useState('')
    const [imageComponent3, setImageComponent3] = useState('')
    const [imageComponent4, setImageComponent4] = useState('')
    const [imageHeight, setImageHeight] = useState('')
    const [imageWidth, setImageWidth] = useState('')

    const [submitted, setSubmitted] = useState(false);

    // states for API
    // const [imageOrientationApi, setImageOrientationApi] = useState('')
    const [imageFrameApi, setImageFrameApi] = useState(null)
    const [imageComponent1Api, setImageComponent1Api] = useState(null)
    const [imageComponent2Api, setImageComponent2Api] = useState(null)
    const [imageComponent3Api, setImageComponent3Api] = useState(null)
    const [imageComponent4Api, setImageComponent4Api] = useState(null)
    // const [imageHeightApi, setImageHeightApi] = useState('')
    // const [imageWidthApi, setImageWidthApi] = useState('')


    // New States for multiple frames
    const [numberOfFrames, setNumberOfFrames] = useState(0);
    const [frames, setFrames] = useState([]);


    // Function to generate frames when small button is clicked
    const handleGenerateFramesInputs = () => {
        // Create an array of objects, each with empty height and width
        const newFrames = Array.from({ length: numberOfFrames }, () => ({ height: '', width: '' }));
        setFrames(newFrames);
    };

    // Update frame dimensions as user types
    const handleFrameChange = (index, field, value) => {
        const updatedFrames = [...frames];
        updatedFrames[index][field] = value;
        setFrames(updatedFrames);
    };


    const formData = new FormData();


    const handleSubmit = async (e) => {
        e.preventDefault();

        formData.append("imageOrientation", imageOrientation);
        formData.append("imageFrame", imageFrameApi);
        formData.append("imageComponent1", imageComponent1Api);
        formData.append("imageComponent2", imageComponent2Api);
        formData.append("imageComponent3", imageComponent3Api);
        formData.append("imageComponent4", imageComponent4Api);
        formData.append("imageHeight", imageHeight);
        formData.append("imageWidth", imageWidth);


        const formValues = {
            imageOrientation: imageOrientation,
            imageFrame: imageFrame,
            imageComponent1: imageComponent1,
            imageComponent2: imageComponent2,
            imageComponent3: imageComponent3,
            imageComponent4: imageComponent4,
            imageHeight: imageHeight,
            imageWidth: imageWidth
        }

        setSubmitted(true)
    }
    const addFrame = async () => {
        console.log('data In API ::', formData);

        const response = await axios.post('http://localhost:3000/add-data', formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            }
        })
            .then(res => console.log('res::', res))
        return response
    }

    function handleOnImageChange(event) {
        const file = event.currentTarget.files[0];
        console.log("file::", file)
        const url = URL.createObjectURL(file);
        return { url, file }
    }


    // const containerStyle = {
    //     position: 'relative',
    //     margin: '50px auto',
    //     width: `${imageWidth ? imageWidth : '200'}px`,
    //     height: `${imageHeight ? imageHeight : '200'}px`,
    // }

    // const frameStyle = {
    //     width: `${imageWidth ? imageWidth : '200'}px`,
    //     height: `${imageHeight ? imageHeight : '200'}px`,
    //     position: 'relative',
    //     top: 0,
    //     left: 0,
    //     border: '1px solid #000000',
    //     objectFit: 'cover',
    // };

    const component1Style = {
        height: '50px',
        width: '50px',
        position: 'absolute',
        top: '100%',
        left: '50%',
        transform: "translate(-50%,-50%)",
        border: '1px solid #000000'
    }
    const component2Style = {
        height: '50px',
        width: '50px',
        position: 'absolute',
        top: '0',
        left: '100%',
        transform: "translate(-50%,-50%)",
        border: '1px solid #000000'
    }
    const component3Style = {
        height: '50px',
        width: '50px',
        position: 'absolute',
        bottom: '0',
        left: '0',
        transform: "translate(-50%,-100%)",
        border: '1px solid #000000'
    }

    const component4Style = {
        height: '50px',
        width: '50px',
        position: 'absolute',
        top: '0',
        right: '100%',
        transform: "translate(50%,-50%)",
        border: '1px solid #000000'
    }

    // const downloadImage = async (index) => {
    //     const div = document.getElementById('divToPrint'); // Your div ID
    //     const canvas = await html2canvas(div);
    //     const image = canvas.toDataURL('image/png');

    //     // Create a download link
    //     const link = document.createElement('a');
    //     link.download = 'converted-image.png';
    //     link.href = image;
    //     link.click();

    // }

    const downloadImage = async (index) => {
        const div = document.getElementById('divToPrint'); // The div you want to convert

        // Step 1: Convert the div to canvas
        const canvas = await html2canvas(div);
    
        // Step 2: Convert the canvas to Blob
        canvas.toBlob((blob) => {
            if (blob) {
                // Step 3: Generate an Object URL
                const objectURL = URL.createObjectURL(blob);
    
                // Use the Object URL (e.g., download, preview, etc.)
                console.log('Object URL:', objectURL);
    
                // Example: Open in a new tab
                window.open(objectURL, '_blank');
    
                // Example: Set as a download link
                const link = document.createElement('a');
                link.href = objectURL;
                link.download = 'converted-div.png';
                link.click();
    
                // Revoke the Object URL when no longer needed
                URL.revokeObjectURL(objectURL);
            }
        });

    }


    return (
        <>
            {/* <form>

                <label htmlFor="imageOrientation">Image Type</label>
                <select name="imageOrientation" id="imageOrientation" onChange={(e) => setImageOrientation(e.target.value)} value={imageOrientation}>
                    <option value="">Select Image orientation</option>
                    <option value="landscape">Landscape</option>
                    <option value="portrait">Portrait</option>
                </select>
                <br /><br />
                <label htmlFor="upload-frame">Upload Frame</label>
                {!imageFrame && <input type="file" name='upload-frame' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageFrame(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageFrameApi(file);
                }} />}

                {imageFrame && <><img src={imageFrame} height='100' width='100' />
                    <button name='button-image-frame' onClick={(e) => setImageFrame('')}>Remove</button></>}
                <br /><br />
                <label htmlFor="upload-component1">Upload Component 1</label>
                {!imageComponent1 && <input type="file" name='upload-component1' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageComponent1(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageComponent1Api(file);
                }} />}
                {imageComponent1 && <><img src={imageComponent1} height='100' width='100' />
                    <button name='button-component-1' onClick={(e) => setImageComponent1('')}>Remove</button></>}
                <br /><br />

                <label htmlFor="upload-component2">Upload Component 2</label>
                {!imageComponent2 && <input type="file" name='upload-component2' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageComponent2(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageComponent2Api(file);
                }} />}

                {imageComponent2 && <><img src={imageComponent2} height='100' width='100' />
                    <button name='button-component-2' onClick={(e) => setImageComponent2('')}>Remove</button></>}

                <br /><br />

                <label htmlFor="upload-component3">Upload Component 3</label>

                {!imageComponent3 && <input type="file" name='upload-component3' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageComponent3(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageComponent3Api(file);
                }} />}

                {imageComponent3 && <><img src={imageComponent3} height='100' width='100' />
                    <button name='button-component-3' onClick={(e) => setImageComponent3('')}>Remove</button></>}
                <br /><br />

                <label htmlFor="upload-component4">Upload Component 4</label>
                {!imageComponent4 && <input type="file" name='upload-component4' onChange={(e) => {
                    const { url, file } = handleOnImageChange(e);
                    console.log(`${e.target.name} url::`, url);
                    setImageComponent4(url);
                    console.log(`${e.target.name} file::`, file);
                    setImageComponent4Api(file);
                }} />}
                {imageComponent4 && <><img src={imageComponent4} height='100' width='100' />
                    <button name='button-component-4' onClick={(e) => setImageComponent4('')}>Remove</button></>}

                <br /><br />

                <label htmlFor="imageSizes">Image Height and Width : </label>
                <input type="number" name='imageLength' style={{ width: '60px', height: '40px' }} onChange={(e) => setImageHeight(e.target.value)} value={imageHeight} />
                <span> X </span>
                <input type="number" name='imageWidth' style={{ width: '60px', height: '40px' }} onChange={(e) => setImageWidth(e.target.value)} value={imageWidth} />
                <br /><br />

                <button onClick={(e) => handleSubmit(e)}>Generate Frame</button>
            </form> */}

            <form className="max-w-md mx-auto bg-white p-6 rounded-md shadow-md space-y-6">
                {/* Image Orientation */}
                <div className="space-y-2">
                    <label
                        htmlFor="imageOrientation"
                        className="block font-semibold text-gray-700"
                    >
                        Image Type
                    </label>
                    <select
                        name="imageOrientation"
                        id="imageOrientation"
                        value={imageOrientation}
                        onChange={(e) => setImageOrientation(e.target.value)}
                        className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    >
                        <option value="">Select Image orientation</option>
                        <option value="landscape">Landscape</option>
                        <option value="portrait">Portrait</option>
                    </select>
                </div>

                {/* Upload Frame */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-frame"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Frame
                    </label>
                    {!imageFrame && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-frame"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageFrame(url);
                                    setImageFrameApi(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageFrame && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageFrame}
                                alt="Frame Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-image-frame"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageFrame('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Upload Component 1 */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-component1"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Component 1
                    </label>
                    {!imageComponent1 && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-component1"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageComponent1(url);
                                    setImageComponent1Api(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageComponent1 && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageComponent1}
                                alt="Component 1 Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-component-1"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageComponent1('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Upload Component 2 */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-component2"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Component 2
                    </label>
                    {!imageComponent2 && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-component2"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageComponent2(url);
                                    setImageComponent2Api(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageComponent2 && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageComponent2}
                                alt="Component 2 Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-component-2"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageComponent2('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Upload Component 3 */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-component3"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Component 3
                    </label>
                    {!imageComponent3 && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-component3"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageComponent3(url);
                                    setImageComponent3Api(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageComponent3 && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageComponent3}
                                alt="Component 3 Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-component-3"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageComponent3('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Upload Component 4 */}
                <div className="space-y-2">
                    <label
                        htmlFor="upload-component4"
                        className="block font-semibold text-gray-700"
                    >
                        Upload Component 4
                    </label>
                    {!imageComponent4 && (
                        <div className="flex items-center space-x-4">
                            <input
                                type="file"
                                name="upload-component4"
                                onChange={(e) => {
                                    const { url, file } = handleOnImageChange(e);
                                    setImageComponent4(url);
                                    setImageComponent4Api(file);
                                }}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border file:border-gray-300 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                            />
                        </div>
                    )}
                    {imageComponent4 && (
                        <div className="flex items-center space-x-4">
                            <img
                                src={imageComponent4}
                                alt="Component 4 Preview"
                                className="h-32 w-32 object-fill border border-gray-200 rounded-md"
                            />
                            <button
                                name="button-component-4"
                                onClick={(e) => {
                                    e.preventDefault();
                                    setImageComponent4('');
                                }}
                                className="px-4 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600 focus:outline-none"
                            >
                                Remove
                            </button>
                        </div>
                    )}
                </div>

                {/* Number of Frames Input */}
                <div className="space-y-2">
                    <label className="block font-semibold text-gray-700">
                        Enter Number of Frames You Want to Generate
                    </label>
                    <div className="flex items-center space-x-2">
                        <input
                            type="number"
                            value={numberOfFrames}
                            onChange={(e) => {
                                setSubmitted(false)
                                setNumberOfFrames(e.target.value)
                            }
                            }
                            className="w-20 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                            placeholder="Count"
                        />
                        <button
                            type="button"
                            onClick={handleGenerateFramesInputs}
                            className="px-3 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 focus:outline-none"
                        >
                            Generate Inputs
                        </button>
                    </div>
                </div>

                {/* Dynamically Render Frame Dimension Inputs */}
                {frames.map((frame, index) => (
                    <div key={index} className="space-y-2">
                        <label className="block font-semibold text-gray-700">
                            Frame {index + 1} Dimensions (Height x Width)
                        </label>
                        <div className="flex items-center space-x-2">
                            <input
                                type="number"
                                value={frame.height}
                                onChange={(e) => handleFrameChange(index, 'height', e.target.value)}
                                className="w-20 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                                placeholder="Height"
                            />
                            <span className="text-gray-500 font-bold">X</span>
                            <input
                                type="number"
                                value={frame.width}
                                onChange={(e) => handleFrameChange(index, 'width', e.target.value)}
                                className="w-20 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                                placeholder="Width"
                            />
                        </div>
                    </div>
                ))}

                {/* Submit Button */}
                <div className="pt-4">
                    <button
                        onClick={(e) => handleSubmit(e)}
                        className="w-full py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    >
                        Generate Frame
                    </button>
                </div>
            </form>


            {/* <CanvasRenderer
                submitted={true}
                imageFrame={imageFrame}
                frames={[
                    { width: 300, height: 200 },
                    { width: 400, height: 250 },
                ]}
                imageComponents={[
                    { imageComponent1 },
                    { imageComponent2 },
                    { imageComponent3 },
                    { imageComponent4 },
                ]}
            /> */}
            {/* Display Generated Frames After Submission */}
            {
                submitted && imageFrame && frames.length > 0 &&
                frames.map((frame, idx) => {
                    console.log(`Index ${idx}: Frame Height:${frame.height} , Frame Width:${frame.width}`);

                    const scaleFactor = (parseFloat(frame.width) + parseFloat(frame.height)) / 2;
                    const componentSizeSmall = scaleFactor * 0.15;
                    const componentSizeTie = scaleFactor * 0.15;
                    const componentSizeBox = scaleFactor * 0.15;

                    const containerStyle = {
                        position: 'relative',
                        margin: '50px auto',
                        width: `${frame.width}px`,
                        height: `${frame.height}px`,
                        border: '1px solid #000000',
                        overflow: 'hidden',
                    };

                    // Inner div scales proportionally
                    const innerDiv = {
                        zIndex: 1,
                        position: 'absolute',
                        width: `calc(100% -  ${frame.width / 7}px)`,
                        height: `calc(100% -  ${frame.height / 7}px)`,
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        backgroundColor: 'white',
                        border: '2px solid red',
                    };



                    // specs top-left
                    const specsStyle = {
                        zIndex: 2,
                        position: 'absolute',
                        width: `${componentSizeSmall}px`,
                        height: `${componentSizeSmall}px`,
                        top: `${frame.height * 0}px`,
                        left: `${frame.width * 0}px`,
                        transform: 'translate(15%, 15%)',
                        border: '1px solid #000000',
                    };

                    // tie top-right
                    const tieStyle = {
                        zIndex: 2,
                        position: 'absolute',
                        width: `${componentSizeTie}px`,
                        height: `${componentSizeTie}px`,
                        top: `${frame.height * 0.0}px`,
                        right: `${frame.width * 0.0}px`,
                        transform: 'translate(25%, 0%)',
                        border: '1px solid #000000',
                    };

                    // sticker bottom-center
                    const stickerStyle = {
                        zIndex: 2,
                        position: 'absolute',
                        width: `${componentSizeSmall}px`,
                        height: `${componentSizeSmall}px`,
                        bottom: `0%`,
                        left: '50%',
                        transform: 'translate(-50%, 0%)',
                        border: '1px solid #000000',
                    };

                    // box aligned left
                    // Use a smaller percentage for left or even a fixed pixel offset to keep it close.
                    const boxStyle = {
                        zIndex: 2,
                        position: 'absolute',
                        width: `${componentSizeBox}px`,
                        height: `${componentSizeBox}px`,
                        top: `${frame.height * 0.65}px`,
                        left: `${frame.width * 0.00}px`,    // smaller than 0.1 to keep it closer to the edge as we scale
                        border: '1px solid #000000',
                        transform: 'translate(-20%, -50%)',
                    };
                    return (
                        
                        <div key={idx}>

                            <div id='divToPrint' style={containerStyle} >
                                {
                                    
                                }
                                <img
                                    style={{
                                        width: '100%',
                                        height: '100%',
                                        position: 'absolute',
                                        top: 0,
                                        left: 0,
                                        objectFit: 'cover',
                                    }}
                                    src={imageFrame}
                                    alt="frame"
                                />
                                <div style={innerDiv}></div>
                                {imageComponent1 && <img src={imageComponent1} alt={`c1-${idx}`} name='comp1' style={specsStyle} />}
                                {imageComponent2 && <img src={imageComponent2} alt={`c2-${idx}`} name='comp2' style={tieStyle} />}
                                {imageComponent3 && <img src={imageComponent3} alt={`c3-${idx}`} name='comp3' style={stickerStyle} />}
                                {imageComponent4 && <img src={imageComponent4} alt={`c4-${idx}`} name='comp4' style={boxStyle} />}
                            </div>
                            <button onClick={downloadImage}> Download Image</button>
                        </div>
                    );
                })
            }

        </>
    )
}

export default Section5