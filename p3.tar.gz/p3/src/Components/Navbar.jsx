import React from 'react'
import '../styles/Navbar.css'

const Navbar = () => {
    return (
        <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#news">News</a></li>
            <li><a href="#contact">Contact</a></li>
            <li style={{float:'right'}}><a className="active" href="#about">About</a></li>
        </ul>
    )
}

export default Navbar