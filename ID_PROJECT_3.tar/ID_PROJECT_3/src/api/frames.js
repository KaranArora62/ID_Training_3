// export const addFrame = async ({formValuesAPI}) => {
//   console.log('in API::',formValuesAPI);

import axios from "axios";

  
//     const response = await fetch('http://localhost:3000/add-data', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify(formValuesAPI),
//       })
//       .then((res) => res.json())
//       return response
// }
const config = {
  headers: {
    'Content-Type': 'multipart/form-data',
  },
};

export const addFrame = async ({formData}) => {
  console.log('in Props::',formData);
  
    const response = await axios.post('http://localhost:3000/add-data', formData, config)
    .then(res => console.log(res))
      return response
}